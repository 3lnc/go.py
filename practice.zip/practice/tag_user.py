from html_tags import b


@b
def talker():
    return 'Talkee'


print talker()
