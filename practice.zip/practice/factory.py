def add_factory(value):
    def func(x):
        return x + value

    return func


add3 = add_factory(3)
add5 = add_factory(5)

type(add3) == type(add5)  # <type 'function'>

assert add3(10) == 13
assert add3(-2) == 1

assert add5(5) == 10
assert add5(8) == 13