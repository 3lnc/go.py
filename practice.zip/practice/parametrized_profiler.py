from time import sleep
from datetime import datetime as dt
from functools import wraps
import pdb


def profile(arg):
    pdb.set_trace()
    if callable(arg):
        FMT = 'Function {} finished in {}'
    else:
        FMT = arg

    def wrapper(func):

        @wraps(func)
        def wrapped(*args, **kwargs):
            start = dt.now()
            res = func(*args, **kwargs)
            end = dt.now()
            print FMT.format(func.__name__, end - start)
            return res

        return wrapped

    if callable(arg):
        return wrapper(arg)
    else:
        return wrapper


@profile('{} -> {}')
#@profile
def slow_func():
    sleep(1)
    return "I'm slow"



print slow_func
print slow_func2