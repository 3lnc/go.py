def b(func):
    def wrapper(*args, **kwargs):
        return '<b>' + func(*args, **kwargs) + '</b>'

    return wrapper


def i(func):
    def wrapper(*args, **kwargs):
        return '<i>' + func(*args, **kwargs) + '</i>'

    return wrapper


def div(color):
    def wrapper(func):
        def wrapped(*args, **kwargs):
            res = func(*args, **kwargs)
            res = '\n'.join(['\t' + i for i in res.split('\n')])
            return '<div style="background-color:#{}">\n'.format(color) + \
                   res + \
                   '\n</div>'

        return wrapped
    return wrapper


@div('22F')
@b
def greetings(name):
    return "Hello {} <br>\nNice to meet you!".format(name)


with open('hello.html', 'w') as f:
    f.write(greetings('World'))
