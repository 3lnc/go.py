def b(func):
    def wrapper(*args, **kwargs):
        return '<b>' + func(*args, **kwargs) + '</b>'

    return wrapper


def i(func):
    def wrapper(*args, **kwargs):
        return '<i>' + func(*args, **kwargs) + '</i>'

    return wrapper


def div(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        res = '\n'.join(['\t' + i for i in res.split('\n')])
        return '<div>\n' + res + '\n</div>'

    return wrapper


def p(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        res = '\n'.join(['\t' + i for i in res.split('\n')])
        return '<p>\n' + res + '\n</p>'

    return wrapper


@div
@div
@p
@b
@i
def greetings(name):
    return "Hello {} <br>\nNice to meet you!".format(name)


with open('hello.html', 'w') as f:
    f.write(greetings('World'))
