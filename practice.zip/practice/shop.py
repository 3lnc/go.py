class User(object):
    def __init__(self, name, year):
        self.name = name
        self.year_registered = year


class Item(object):
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def __repr__(self):
        return 'Item({}, {})'.format(self.name, self.price)


class Order(object):
    def __init__(self, user, item_list):
        if not isinstance(user, User):
            raise TypeError('user should inherits User class')
        self.user = user
        self.items = item_list

    @property
    def cost(self):
        return sum([item.price * count for item, count in self.items.items()])


if __name__ == '__main__':
    user = User('Ivan', 2002)
    assert user.name == 'Ivan'
    assert user.year_registered == 2002

    pen = Item('Pen', 1)
    assert pen.name == 'Pen'
    assert pen.price == 1

    order1 = Order(user, {Item('Pencil', 0.5): 1, Item('Marker', 1.2): 2})
    assert order1.user.name == 'Ivan'
    assert len(order1.items) == 2
    assert order1.cost == 2.9

    print {Item('Pencil', 0.5): 1, Item('Marker', 1.2): 2}
