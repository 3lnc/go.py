def b(func):
    def wrapper(*args, **kwargs):
        return '<b>' + func(*args, **kwargs) + '</b>'

    return wrapper


def i(func):
    def wrapper(*args, **kwargs):
        return '<i>' + func(*args, **kwargs) + '</i>'

    return wrapper


def div(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        res = '\n'.join(['\t' + i for i in res.split('\n')])
        return '<div>\n' + res + '\n</div>'

    return wrapper


def p(func):
    def wrapper(*args, **kwargs):
        res = func(*args, **kwargs)
        res = '\n'.join(['\t' + i for i in res.split('\n')])
        return '<p>\n' + res + '\n</p>'

    return wrapper


if __name__ == '__main__':
    @b
    def x():
        return 'abc'

    assert x() == '<b>abc</b>'
    print 'All ok!'