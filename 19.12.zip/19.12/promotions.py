all_discounts = []


def discount(func):
    all_discounts.append(func)
    return func


@discount
def loyalty_discount(order):
    if order.user.years > 10:
        return 0.05 * order.cost
    else:
        return 0


@discount
def big_cost_discount(order):
    if order.cost > 1000:
        return 0.04 * order.cost
    else:
        return 0


@discount
def bulk_discount(order):
    if order.max_single_count > 100:
        return 0.1 * order.cost
    else:
        return 0


@discount
def distinct_discount(order):
    if order.distinct_count >= 5:
        return 0.04 * order.cost
    else:
        return 0


def best_discount(order):
    return max([f(order) for f in all_discounts])
