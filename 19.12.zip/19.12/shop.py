from datetime import datetime as dt


class User(object):
    def __init__(self, name, year):
        self.name = name
        try:
            year = int(year)
        except:
            raise TypeError('Year must be integer')
        self.year_registered = year

    @property
    def years(self):
        return dt.now().year - self.year_registered


class Item(object):
    def __init__(self, name, price):
        self.name = name
        self.price = price


class Order(object):
    def __init__(self, user, item_list):
        self.user = user
        self.items = item_list

    @property
    def cost(self):
        return sum([item.price * count for item, count in self.items.items()])

    @property
    def max_single_count(self):
        return max(self.items.values())

    @property
    def distinct_count(self):
        return len(self.items.keys())
