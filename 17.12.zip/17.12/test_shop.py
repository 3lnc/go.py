import unittest
from shop import User, Item, Order


class UserTestCase(unittest.TestCase):
    def test_name(self):
        user = User('Ivan', 2002)
        self.assertEqual(user.name, 'Ivan')

    def test_year_registered(self):
        user = User('Ivan', 2002)
        self.assertEqual(user.year_registered, 2002)

    def test_years(self):
        user = User('Ivan', 2002)
        self.assertEqual(user.years, 13)



class ItemTestCase(unittest.TestCase):
    def test_attributes(self):
        pen = Item('Pen', 1)
        self.assertEqual(pen.name, 'Pen')
        self.assertEqual(pen.price, 1)


class OrderTestCase(unittest.TestCase):
    def test_attributes(self):
        user = User('Ivan', 2002)
        order = Order(user, {Item('Pencil', 0.5): 1, Item('Marker', 1.2): 2})
        self.assertEqual(order.user.name, 'Ivan')
        self.assertEqual(len(order.items), 2)

    def test_cost(self):
        user = User('Ivan', 2002)
        order = Order(user, {Item('Pencil', 0.5): 1, Item('Marker', 1.2): 2})
        self.assertEqual(order.cost, 2.9)

    def test_max_single_count(self):
        user = User('Ivan', 2002)
        order = Order(user, {Item('Pencil', 0.5): 1, Item('Marker', 1.2): 2})
        self.assertEqual(order.max_single_count, 2)

    def test_max_equal_single_count(self):
        user = User('Ivan', 2002)
        order = Order(user, {Item('Pencil', 0.5): 10, Item('Marker', 1.2): 10})
        self.assertEqual(order.max_single_count, 10)


if __name__ == '__main__':
    unittest.main(verbosity=1)
